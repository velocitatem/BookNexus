#include <iostream>
#include "Items.h"
#include "library.h"

using namespace std;

int main() {
    Library library("IE Library");

    Book book("Thinking", "Author", 500, 2);
    Book book1("Talking", "Person", 500, 9);
    Book book2("Talking", "Person", 500, 9);
    Magazine magazine("Forbes", "Big Person", 20, 100);

    library.add_item(&book);
    library.add_item(&book1);
    library.add_item(&book2);

    // =================== LOADED ===============
    string q1_ = "Talking by Person";
    LibraryItem * q1 = library.search_item(q1_);
    cout << "Search for " << q1_ << " yielded " << q1->get_remaining() << " results" << endl;

    string q2_ = "Inferno by Dan Brown";
    LibraryItem * q2 = library.search_item(q2_);
    cout << "Search for " << q2_ << " yielded " << q2->get_remaining() << " results" << endl;

    library.remove_item(&book1);

    q1 = library.search_item(q1_);
    cout << "Search for (after deleting) " << q1_ << " yielded " << q1->get_remaining() << " results" << endl;


    string q3_ = "Thinking by Author";
    LibraryItem * q3 = library.search_item(q3_);
    cout << "Search for " << q3_ << " yielded " << q3->get_remaining() << " results" << endl;
    cout << "Do you want to check-out this book? 1 for yes 0 for no" << endl;
    bool checkout_yn = false;
    cin >> checkout_yn;
    if (checkout_yn) {
        bool exito = library.checkout(q3);
        if (exito) {
            cout << "Checkout successful, " << q3->get_remaining() << " copies remaining" << endl;
        }
        else {
            cout << "Checkout failed" << endl;
        }

    }
    cout << "Goodbye" << endl;

    return 0;
}
